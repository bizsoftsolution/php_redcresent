<?php

$body="";

if(isset($_REQUEST['name']))
		{

			$body='<h1 style="text-align:center;">Malaysian Red Crescent, Klang District</h1>
<h2 style="text-align:center;">Run Humanity</h2>

<table border="1" cellpadding="30" cellspacing="">
	<tr>
		<td col-span="2">Registration Form</td>
	</tr>
	<tr>
		<td>FULL NAME</td>
		<td>'.$_REQUEST['name'].'</td>
		<td>IC/PASSPORT NO</td>
		<td>'.$_REQUEST['name1'].'</td>
		
	</tr>

	<tr>
		<td>AGE</td>
		<td>'.$_REQUEST['name2'].'</td>
		<td>SEX</td>
		<td>'.$_REQUEST['name3'].'</td>
	</tr>

	<tr>
		<td>NATIONALITY</td>
		<td>'.$_REQUEST['name4'].'</td>
		<td>RACE</td>
		<td>'.$_REQUEST['name5'].'</td>
	</tr>

	<tr>
		<td>DATE OF BIRTH</td>
		<td>'.$_REQUEST['name6'].'</td>
		<td>CONTACT NUMBER</td>
		<td>'.$_REQUEST['name7'].'</td>
		
	</tr>

	<tr>
		<td>EMAIL-ID</td>
		<td>'.$_REQUEST['name8'].'</td>
		<td>MAILING ADDRESS</td>
		<td>'.$_REQUEST['name9'].'</td>
	</tr>

	<tr>
		<td>POST CODE</td>
		<td>'.$_REQUEST['name9'].'</td>

		<td>CITY</td>
		<td>'.$_REQUEST['name10'].'</td>
		
	</tr>
	<tr>
		<td>STATE</td>
		<td>'.$_REQUEST['name11'].'</td>

		<td>COUNTRY</td>
		<td>'.$_REQUEST['name12'].'</td>
		
	</tr>
	<tr>
		<td>COUNTRY</td>
		<td>'.$_REQUEST['name13'].'</td>

		<td>PAYMENT METHOD</td>
		<td >'.$_REQUEST['name14'].'</td>
		
	</tr>
	<tr>
		<td>SCHOOL NAME</td>
		<td colspan="3">'.$_REQUEST['name15'].'</td>
		
	</tr>
	<tr>
		<td>T-SHIRT SIZE CHART(ADULT)</td>
		<td>'.$_REQUEST['name16'].'</td>

		<td>T-SHIRT SIZE CHART(KIDS)</td>
		<td>'.$_REQUEST['name17'].'</td>
		
	</tr>
	<tr>
		<td colspan="3"><h1>EMERGENCY CONTACT</h1><td>
	</tr>
	<tr>
		<td>CONTACT NAME</td>
		<td>'.$_REQUEST['name18'].'</td>

		<td>CONTACT NUMBER</td>
		<td>'.$_REQUEST['name19'].'</td>
		
	</tr>
	<tr>
		<td colspan="2">RELATIONSHIP</td>
		<td colspan="2">'.$_REQUEST['name20'].'</td>
		
	</tr>

</table>';		
		}

		
		date_default_timezone_set('Etc/UTC');

		require 'include/PHPMailerAutoload.php';
		$mail = new PHPMailer;
		$mail->isSMTP();
//		$mail->SMTPDebug = 2;
		//$mail->Debugoutput = 'html';
		$mail->Host ="www.ntc.my";
		$mail->Port = 25;
//$mail->isSMTP();
//$mail->Host = 'relay-hosting.secureserver.net';
//$mail->Port = 25;
$mail->SMTPAuth = false;
$mail->SMTPSecure = false;
		//$mail->SMTPAuth = false;
		$mail->Username = "mail@ntc.my";
		$mail->Password = "test123!@#";
		$mail->setFrom('mail@ntc.my', 'redcrescentklang');
		$mail->addReplyTo('mail@ntc.my', 'redcrescentklang');
		$mail->addAddress('jasper_0214@yahoo.com.sg', 'Register Form');
$mail->addAddress('anitha.bizsoft@gmail.com', 'Register Form');
$mail->addAddress('govindarajselvam90@gmail.com', 'Register Form');
		$mail->Subject = 'redcrescentklang Register Form';
		$mail->msgHTML($body);
if (isset($_FILES['file']) &&
    $_FILES['file']['error'] == UPLOAD_ERR_OK) {
    $mail->AddAttachment($_FILES['file']['tmp_name'],
                         $_FILES['file']['name']);
}
		//$mail->AltBody = 'Hi';
//var_dump($mail);
		if (!$mail->send()) {
			echo "<script>javascript: alert('test msgbox')></script>";
		} else {
			echo '<script type="text/javascript">alert("Message Send Successfully");window.location="index.html";</script>';
		}
	