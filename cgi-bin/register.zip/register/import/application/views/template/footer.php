

    <!-- Footer -->
    <div class="footer text-muted">
      &copy; 2017. <a href="#">Run Humanity</a> by <a href="http://www.denariusoft.com" target="_blank">Denariusoft</a>
    </div>
    <!-- /footer -->

  </div>
  <!-- /content area -->

</div>

		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->

</body>
</html>
