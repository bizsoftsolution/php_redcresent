        <!-- Start Header & Navigation Section -->
        <header class="clearfix" id="header">
            <!-- Static navbar -->
            <nav class="navbar navbar-default navbar-fixed-top">
                 
                <div class="container">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="<?php echo base_url();?>"><img alt="" src="<?php echo base_url('assets/front-end/images/logo/mlogo.png')?>"></a>
                    </div>
                    <div class="navbar-collapse collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li class="drop"><a href="<?php echo base_url();?>Front/index">Home</a>                             
                                
                            
                            </li>
                            <li class="megadrop"><a href="<?php echo base_url();?>Front/service">Services</a>
                              
                            </li>
                            <li class="drop"><a href="<?php echo base_url();?>Front/gallery">Gallery</a>                             
                            </li>
                            <li class="drop"><a href="<?php echo base_url();?>Front/about">About</a>
                                
                            </li>
                            <li class="drop"><a href="<?php echo base_url();?>Front/contact">Contact</a>
                                
                            </li>
                           
                                                    
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div> 
                           
                        </ul>
                    </div>
                </div>
            </nav>
        </header>
	
	