<!DOCTYPE html>
<html lang="en">

<head>
      
    </head>
    <body>
             <!-- Start Text & Image Section -->
        <section class="pad100">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 col-sm-8">
					<h3 style="color:#598084;"> Malaysian Red Crescent(Chapter Klang)Restoring Family Links
</h3><br>
                        <div class="text-center">
                            <img src="<?php echo base_url('assets/front-end/images/services/family.png')?>" alt="" class="img-responsive">
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="text-section-left">
                            <div class="text-section-title">
                                <h3>ABOUT<span>US</span></h3>
                            <img src="<?php echo base_url('assets/front-end/images/logo/aboutlogo.jpg')?>" alt="" class="img-responsive">
                            </div>
                            <p style="text-align:justify;">  The Malaysian Red Crescent (MRC) is a non-profit organisation dedicated to humanitarian acts and services.</p>
                           <!--  <ul class="fa-ul">
                                <li><i class="fa-li fa fa-check-circle"></i>Interdum et malesuada fames ac ante</li>
                                <li><i class="fa-li fa fa-check-circle"></i>Malesuada fames ac ante ipsum</li>
                                <li><i class="fa-li fa fa-check-circle"></i>Nam blandit quam nibh, at fermentum</li>
                            </ul> -->
                            <div class="call-to-action-btn" style="margin-top: 20px;">
                                <!--a href="#" class="btn btn-primary">Know More</a-->
                            </div>
                        </div>
                    </div>
					
                </div>
				
				<div class="row">
					<div class="col-md-8 col-sm-8">
                        <div class="text-section-left">
                            <div class="text-section-title">
                                <h3> Restoring Family Links <span>(RFL)</span></h3>
                            </div>
                            <p style="text-align:justify;">
           When a disaster or conflict occurs, families are sometimes separated; sometimes it is due to relocation or detention as a result of civil unrest or war. Using our local and international network MRC is able to assist in tracing and reconnecting family members during or after these incidents. This service is provided free of charge and run mostly by our volunteers.<br><br>
		   <h3>How to utilise our RFL service</h3><br><br>
		   Here are some tips and steps to take if you find yourself separated or relocated:<br><br>
		   Register yourself with the relevant authorities and the Malaysian Red Crescent to ensure that you are accounted for and able to be located.<br><br>
		   If you have family members overseas who may be involved in a major disaster, you may make enquiries via relevant authorities or to MRC after 72 hours.<br><br>
		   Our tracing service does not cover normal missing person's cases or court cases handled by police.<br><br>
		   The Red Cross Message is a service whereby an open letter, containing only neutral family news, is delivered to a person at detention depots or conflict areas. MRC and the relevant authorities will screen the message prior to acceptance and delivery. Photos and documents attachments are allowed, again subject to scrutiny and approval.<br><br>
		   This service is available worldwide through our network of Red Cross and Red Crescent organisations and is provided only if there are no other normal means of communications available.<br><br>
		   Full contact details, supporting documents and background history of separation and or news of loss are to be provided to initiate our services.<br><br>
		   The service is run mostly by volunteers and provided free of charge. We do not commit to a certain time frame to locate or send family news. If Sought Person(s) is/are not found and message is undeliverable due to inadequate information, security reasons or relocation, the Enquirer or Sender will be notified. If the sought person is found and there is a reply the enquirer will be notified.<br><br>
		   For assistance and further information on utilising this service please contact us via e-mail:<br><br>
		   secgen@redcrescent.org.my<br><br>

or<br><br>

rflmalaysia@redcrescent.org.my

							</p>
                           <!--  <ul class="fa-ul">
                                <li><i class="fa-li fa fa-check-circle"></i>Interdum et malesuada fames ac ante</li>
                                <li><i class="fa-li fa fa-check-circle"></i>Malesuada fames ac ante ipsum</li>
                                <li><i class="fa-li fa fa-check-circle"></i>Nam blandit quam nibh, at fermentum</li>
                            </ul> -->
<!--                             <div class="call-to-action-btn" style="margin-top: 20px;">
                                <a href="#" class="btn btn-primary">Know More</a>
                            </div> -->
                        </div>
                    </div>
					
					 <div class="col-md-4 col-sm-4">
                        <div class="text-section-left">
                            <div class="text-section-title">
                                <h3> Categories
 <span></span></h3>
                            <!--img src="assets/images/logo/aboutlogo.jpg" alt="" class="img-responsive"-->
                            </div>
                            <p style="text-align:justify;">  </p>
                           <!--  <ul class="fa-ul">
                                <li><i class="fa-li fa fa-check-circle"></i>Interdum et malesuada fames ac ante</li>
                                <li><i class="fa-li fa fa-check-circle"></i>Malesuada fames ac ante ipsum</li>
                                <li><i class="fa-li fa fa-check-circle"></i>Nam blandit quam nibh, at fermentum</li>
                            </ul> -->
                            <div class="call-to-action-btn" style="margin-top: 20px;">
                                <a href="#" class="btn btn-primary">First Aid Training </a><br>
					           <a href="#" class="btn btn-primary">Blood Donation </a><br>
							   <a href="#" class="btn btn-primary"> Strategy 2020</a>
                            </div>
                        </div>
                    </div>
            </div>
		</div>	
        </section>
        <!-- End Text & Image Section -->

      

      
        


        <div id="back-to-top" class="back-to-top reveal">
            <i class="fa fa-angle-up fa-2x"></i>
        </div>
        

      
        
        

        <!-- all js include start -->
        <!-- jquery latest version -->
        <script src="assets/js/jquery-3.1.1.min.js"></script>
        <!-- bootstrap latest version -->
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>

        <!-- revolution slider js files start -->
        <script src="assets/js/rev_slider/jquery.themepunch.tools.min.js"></script>
        <script src="assets/js/rev_slider/jquery.themepunch.revolution.min.js"></script>
        
        <script src="assets/js/rev_slider/extensions/revolution.extension.actions.min.js"></script>
        <script src="assets/js/rev_slider/extensions/revolution.extension.carousel.min.js"></script>
        <script src="assets/js/rev_slider/extensions/revolution.extension.kenburn.min.js"></script>
        <script src="assets/js/rev_slider/extensions/revolution.extension.layeranimation.min.js"></script>
        <script src="assets/js/rev_slider/extensions/revolution.extension.migration.min.js"></script>
        <script src="assets/js/rev_slider/extensions/revolution.extension.navigation.min.js"></script>
        <script src="assets/js/rev_slider/extensions/revolution.extension.parallax.min.js"></script>
        <script src="assets/js/rev_slider/extensions/revolution.extension.slideanims.min.js"></script>
        <script src="assets/js/rev_slider/extensions/revolution.extension.video.min.js"></script>
        <!-- revolution slider js files end -->

        <!-- Other jQuery library -->
        <script src="assets/js/jquery.appear.js"></script>
        <script src="assets/js/jquery.countTo.js"></script>
        <script src="assets/js/jquery.isotope.min.js"></script>
        <script src="assets/js/lightbox.js"></script>
        <script src="assets/js/owl.carousel.js"></script>
        <script src="assets/js/jquery.easypiechart.js"></script>
        <script src="assets/js/jquery.mb.YTPlayer.js"></script>
        <script src="assets/js/jquery.ui.core.min.js"></script>
        <script src="assets/js/jquery-ui-1.9.2.datepicker.min.js"></script>
        

        <!-- template main js file -->
        <script src="assets/js/main.js"></script>
        <!-- all js include end -->
 
 