
		
		
        <!-- Start Footer Section-->
        <section class="pad-t100 pad-b70 footer-section" style="background-color: #111;">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-sm-4" style="margin-bottom: 30px;">
                     <h4>  <a style="color:#fff;">ABOUT US</a></h4><br>
						<!--img src="assets/images/logo/mlogo.png" class="footer-logo" alt="Footer Logo"-->
                        <div class="footer-text">
                            <p>Human dignity and peace throughout the world. Prevent and alleviate human suffering through humanitarian activities and actions.

 </p>
                            <p> MEMBERS
    The Malaysian Red Crescent(MRC) (Chapter Klang) has several members.

</p>
                        </div>
                        
                    </div>
                    <div class="col-md-4 col-sm-4" style="margin-bottom: 30px;">
                        <div class="section-title-2 white">
                            <h3>SOCIAL MEDIA</h3>
                        </div>
                      
                        <div class="footer-social">
                            <ul>
                                <li>
                                    <a href="#" target="_blank"><i class="fa fa-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="#" target="_blank"><i class="fa fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#" target="_blank"><i class="fa fa-google-plus"></i></a>
                                </li>
                                <li>
                                    <a href="#" target="_blank"><i class="fa fa-youtube"></i></a>
                                </li>
                                <li>
                                    <a href="#" target="_blank"><i class="fa fa-linkedin"></i></a>
                                </li>
                                <li>
                                    <a href="#" target="_blank"><i class="fa fa-rss"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                   
                    <div class="col-md-4 col-sm-4" style="margin-bottom: 30px;">
                        <div class="section-title-2 white">
                            <h3>Contact</h3>
                        </div>
                        <p>No.7A,Jalan tengku Diauddin,41000,Klang ,Selangor Darulehsan.</p>
                        <p>Tel: 603-33727454 </p>
                        <p>Email: mrcstraining@yahoo.com.my</p>
                        <!--p>Working Hours: 8:00 a.m - 17:00 a.m</p-->
                    </div>
                </div>
            </div>
        </section>
        <!-- End Footer Section-->
		
		 <!-- Start Copyright Section -->
        <section class="copyright-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-6">
                        <div class="copyright">
                            <p>Copyright © 2017 - All Rights reserved <!--i class="fa fa-heart"></i--></p>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="footer-nav">
                            <!-- <ul>
                                <li><a href="#">Home</a></li>
                                <li><a href="#">Joomla</a></li>
                                <li><a href="#">Contact</a></li>
                            </ul> -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- End Copyright Section -->

        <div id="back-to-top" class="back-to-top reveal">
            <i class="fa fa-angle-up fa-2x"></i>
        
		
	</div>
	  
        <!-- all js include end -->
</div>

</body>
</html>
       