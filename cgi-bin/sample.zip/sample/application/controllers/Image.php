<?php
 class Image extends CI_Controller
 {

  function __construct()
  {
    parent::__construct();
    $this->load->model('ImageModel', 'imageModel');
    $this->load->helper('url');
	  $this->load->library('session');
  }

 public function addNew()
  {
    $result = array('message'=>'');	
	if($this->input->post('submit_image_data'))
		{	
			// multiple upload coding start
			
			$files = $_FILES;
			$images = array();
			$cpt = count($_FILES['file']['name']);
			for($i=0; $i<$cpt; $i++){
			$_FILES['file']['name']= $files['file']['name'][$i];
			$_FILES['file']['type']= $files['file']['type'][$i];
			$_FILES['file']['tmp_name']= $files['file']['tmp_name'][$i];
			$_FILES['file']['error']= $files['file']['error'][$i];
			$_FILES['file']['size']= $files['file']['size'][$i];
			$config['upload_path'] = './upload/images/';
			$config['allowed_types'] = 'gif|jpg|png';
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			
			if ($this->upload->do_upload('file'))
			{
				$this->upload->data();
				$images[] = $_FILES['file']['name'];
			}
			}
			$fileName = implode(',',$images);
			
			// multiple upload coding End
			
            $userData = array(
				'categery'=>$this->input->post('category_name'),
				'img_name' => $fileName
            );          
			//Pass user data to model
			$result['message'] = $this->imageModel->addNew($userData);
			if($result['message'] == 'SUCCESS')
			{
				
				$base_url=base_url();
				redirect("$base_url"."Image/addNew");
			}
        }		
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    //$this->load->view('template/content');
    $this->load->view('front/addNew', $result);
    $this->load->view('template/footer');
  }
  
  function allgallery()
  {
    $data['gallerylist']=$this->imageModel->gallerylist();
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    $this->load->view('front/galleryList',$data);
    $this->load->view('template/footer');
  }
  public function edit($id)
  {
      $result = array('message'=>'');
      if($this->input->post('Category_name'))
      {
  		  $userData = array(
			'categery' => $this->input->post('Category_name')
  		);
  		$result['message'] = $this->imageModel->update_entry($userData,$id);
      if($result['message'] == 'SUCCESS')
      {
        $base_url=base_url();
        redirect("$base_url"."Image/allgallery");
      }
    }
	
	if($this->input->post('update_category_gallery'))
		{	
			// multiple upload coding start
			
			$files = $_FILES;
			$images = array();
			$cpt = count($_FILES['file']['name']);
			for($i=0; $i<$cpt; $i++){
			$_FILES['file']['name']= $files['file']['name'][$i];
			$_FILES['file']['type']= $files['file']['type'][$i];
			$_FILES['file']['tmp_name']= $files['file']['tmp_name'][$i];
			$_FILES['file']['error']= $files['file']['error'][$i];
			$_FILES['file']['size']= $files['file']['size'][$i];
			$config['upload_path'] = './upload/images/';
			$config['allowed_types'] = 'gif|jpg|png';
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			
			if ($this->upload->do_upload('file'))
			{
				$this->upload->data();
				$images[] = $_FILES['file']['name'];
			}
			}
			$fileName = implode(',',$images);
			
			// multiple upload coding End
			
            $userData = array(
				'img_name' => $fileName
            );          
			//Pass user data to model
			$result['message'] = $this->imageModel->update_entry($userData,$id);
			if($result['message'] == 'SUCCESS')
			{
				
				$base_url=base_url();
				redirect("$base_url"."Image/allgallery");
			}
        }
		
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    $result['galleryupdate']=$this->imageModel->get($id);
    $this->load->view('front/galleryupload',$result);
    $this->load->view('template/footer');
}

  public function delete($id)
  {
    $this->imageModel->delete_entry($id);
	$data['gallerylist']=$this->imageModel->gallerylist();
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    $this->load->view('front/galleryList',$data);
    $this->load->view('template/footer');
  }
  
  public function addSlider()
  {
    $result = array('message'=>'');	
	if($this->input->post('submit_image_data'))
		{	
			// multiple upload coding start
			
			$files = $_FILES;
			$images = array();
			$cpt = count($_FILES['file']['name']);
			for($i=0; $i<$cpt; $i++){
			$_FILES['file']['name']= $files['file']['name'][$i];
			$_FILES['file']['type']= $files['file']['type'][$i];
			$_FILES['file']['tmp_name']= $files['file']['tmp_name'][$i];
			$_FILES['file']['error']= $files['file']['error'][$i];
			$_FILES['file']['size']= $files['file']['size'][$i];
			$config['upload_path'] = './upload/slider/';
			$config['allowed_types'] = 'gif|jpg|png';
			$this->load->library('upload', $config);
			$this->upload->initialize($config);
			
			if ($this->upload->do_upload('file'))
			{
				$this->upload->data();
				$images[] = $_FILES['file']['name'];
			}
			}
			$fileName = implode(',',$images);
			
			// multiple upload coding End
			
            $userData = array(
				'img_name' => $fileName
            );          
			//Pass user data to model
			$result['message'] = $this->imageModel->addSlider($userData);
			if($result['message'] == 'SUCCESS')
			{
				
				$base_url=base_url();
				redirect("$base_url"."Image/addSlider");
			}
        }		
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    //$this->load->view('template/content');
    $this->load->view('front/addSlider', $result);
    $this->load->view('template/footer');
  }
  
  function allslider()
  {
    $data['sliderlist']=$this->imageModel->sliderlist();
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    $this->load->view('front/sliderList',$data);
    $this->load->view('template/footer');
  }
  public function delete_slider($id)
  {
    $this->imageModel->delete_slider($id);
	$data['sliderlist']=$this->imageModel->sliderlist();
    $this->load->view('template/header');
    $this->load->view('template/sidebar');
    $this->load->view('front/sliderList',$data);
    $this->load->view('template/footer');
  }
  
 }
?> 
 